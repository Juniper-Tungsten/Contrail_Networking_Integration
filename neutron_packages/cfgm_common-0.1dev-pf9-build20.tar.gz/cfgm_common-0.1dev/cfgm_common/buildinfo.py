build_info = "{\"build-info\" : [{\"build-version\" : \"4.0.0.0\", \"build-time\" : \"2017-06-05 00:52:01.295747\", \"build-user\" : \"contrail-builder\", \"build-hostname\" : \"ubuntu\", ";
